var ref = new Firebase("https://c4c-cookbook.firebaseio.com/");

/*myFirebaseRef.set({
	recipe_name:"test",
	category:{
		breakfast:0,
		lunch_dinner:0,
		snack:0,
		dessert:0,
		drink:0,
		vegetarian:0,
		odd:0,
		soup_salad:0
	},
	ingredients:"test",
	prepare:"test",
	difficulty:3,
	tags:["test1","test2","test3"]
});
myFirebaseRef.child("ingredients").on("value", function(snapshot) {
  alert(snapshot.val());
});*/

$(document).ready(function(){

$("#submit").click(function(){

	var recipeRef=ref.child("c5c-cookbook");
	var tagsArray=$("#tags").val().split(", ");
	// hamdling checkboxes
	// initialize an empty array
	//var checkedCategories = []

	// use a for loop to push checked values into the checked categories array
	var newRecipeRef=recipeRef.push();
	// console.log("got here above",tagsArray);
	newRecipeRef.set({
		recipe_name:$("#recipe_name").val(),
		// categories : checkedCategories.split(',')
		category:{
			breakfast:$("#breakfast").val(),
			// lunch_dinner:$("#lunch_dinner").val(),
			// snack:$("#snack").val(),
			// dessert:$("#dessert").val(),
			// drink:$("#drink").val(),
			// vegetarian:$("#vegetarian").val(),
			// odd:$("#odd").val(),
			// soup_salad:$("#soup_salad").val()
		},
		ingredients:$("#ingredient").val(),
		prepare:$("#prepare").val(),
		difficulty:$("#range").val(),
		tags:tagsArray

	});
	console.log("got here");

}); //submit on click
}); //document on ready