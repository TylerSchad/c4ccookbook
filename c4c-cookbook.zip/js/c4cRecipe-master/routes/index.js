//routes/index.js
///in tut=app/routes.js
module.exports = function(app,passport){
  //route to home page
  app.get('/',function(req,res){
    res.render('index.ejs');
  });

  //routes to login page
  app.get('/login',function(req,res){//route get req to /login
    res.render('login.ejs',{message: req.flash('loginMessage')});
  });
  //passport stuff below
  app.post('/login',passport.authenticate('local-login',{
    successRedirect:'/profile',//redirect to profy
    failureRedirect:'/login',//try again
    failureFlash:true//allow flash msgs
  }));

  //routes to signup page
  app.get('/signup',function(req,res){//route get req to /signup
    res.render('signup.ejs',{message:req.flash('signupMessage')});
  });
  //do passport stuff
  //process signup form
  app.post('/signup',passport.authenticate('local-signup',{
    successRedirect:'/profile',//redirect to secure prof page
    //could use callback instead(successRedirect) to really take control
    failureRedirect:'/signup',//send back
    failureFlash:true//allow flash message
  }));

  //submit new recipe
  app.get('/new',function(req,res){//route to submit new recipe
    res.render('newRecipe.ejs',{message:req.flash('newMessage')});
  });
  //deal with new recipe submission
  app.post('/new',function(input){

  });

  //get profy page
  app.get('/profile',isLoggedIn, function(req,res){
    res.render('profile.ejs',{
      user:req.user
    });
  });

  //handle photo upload
  app.post('/uploads',function(req,res){

  });

  //get random recipe
  app.get('/random',function(req,res){
      res.render('random.ejs');
  });

  //route to logout page
  app.get('/logout',function(req,res){
    req.logout();
    req.render('/');//send em back to start
  });
};//end module.exports

//route middlW to ensure user logged in
function isLoggedIn(req,res,next){
  //if autN in sess, move on
  if(req.isAuthenticated()){
    return next();
  }

  //if aren't redirected to home
  res.redirect('/');
}
