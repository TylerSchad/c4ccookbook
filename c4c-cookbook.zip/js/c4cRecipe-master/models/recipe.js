//models/recipe.js
//recipe model (basically a class)

var mongoose=require('mongoose');

//define schema for model
var recipeSchema = mongoose.Schema({
  local   :{
    difficulty:Number,
    name:String,
    picURL:String,
    category:[{type:String,max:3}],//max of 3 categories
    tags:[{type:String,max:5}],//max of 5 tags
    ingredients:[String]
  }
});

//methods
//get random recipe
recipeSchema.methods.getRandom = function(){

};

//save Recipe
recipeSchema.methods.saveRecipe = function(){

}

//create model for users & expose to our app
module.exports = mongoose.model('Recipe',recipeSchema);
