# c4cRecipe
c4c recipe web app for HackCU
social recipe book for wacky food combos in C4C @ CU 
web app written and powered by the one, the only, Node.js and the wonderful MEAN stack
