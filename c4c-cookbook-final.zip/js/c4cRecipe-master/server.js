//server.js
var express = require('express');
var app=express();
var port = process.env.PORT || 8080;
var mongoose = require('mongoose');
var db = mongoose.connect('mongodb://localhost/c4');
var passport=require('passport');//helps with authN
var flash = require('connect-flash');
var morgan = require('morgan');
var cookiePars = require('cookie-parser');
var bodyPars = require('body-parser');
var session = require('express-session');
var multer = require('multer');

require('./config/passport')(passport);//pass passport for config

//set up express app
app.use(morgan('dev'));//log every req to console
app.use(cookiePars());//read cooks for authN
app.use(bodyPars());//get info from html forms

app.set('view engine','ejs');//setup ejs for templating

//setup passport
app.use(session({secret: 'superspecialsecretec4c4u'}));//session secret
app.use(passport.initialize());
app.use(passport.session());//persistent login sess

app.use(flash());//use connect-flash for messages in sess

//routes
require('./routes/index.js')(app,passport);//load routes

app.listen(port,function(){
  console.log('server listening: '+port);
});
