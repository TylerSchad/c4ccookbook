//config/passport.js

//load erything
var LocalStrategy = require('passport-local').Strategy;

//load user model
var User = require('../models/user');

//expose this function to our app using module.exports
module.exports = function(passport){
  //passport sess setup
  ///req for persistent login sess'
  ///passport needs ability to serialize and unserialize

  //used to serialize the user for sess
  passport.serializeUser(function(user,done){
    done(null, user.id);
  });

  //used to deserialize
  passport.deserializeUser(function(id,done){
    User.findById(id,function(err,user){
      done(err,user);
    });
  });

  //local signup
  //using named strategies since have ones for login & signup
  passport.use('local-signup', new LocalStrategy({
    //by def, local strategy uses username & pass
    usernameField: 'email',
    passwordField: 'password',
    passReqToCallback:true//allows us to pass back the entire req to callback
  },
  function(req,email,password,done){
    //async
    //User.finOne wont fire unless data is sent back
    process.nextTick(function(){
      //find user whose email is same as forms email
      //checking if user logging in already exists
      User.findOne({ 'local.email':email},function(err,user){
        if(err) return done(err);

        //check if user already exists
        if(user){
          return done(null,false,req.flash('signupMessage','email already taken'));
        }else{
          //if user !exists
          var newUser = new User();
          newUser.local.email = email;
          newUser.local.password = newUser.generateHash(password);//hash & set pass

          //save user
          newUser.save(function(err){
            if(err) throw err;
            return done(null, newUser);
          });
        }
      });
    });
}));

passport.use('local-login',new LocalStrategy({
  //by def local strategy uses username & pass
  usernameField: 'email',
  passwordField: 'password',
  passReqToCallback:true//enable pass back entire req to callback
},
function(req,email,password,done){//callback w/ values from form
  //find user w/ same email
  User.findOne({'local.email':email},function(err,user){
    if(err) return done(err);

    //no user found, return message
    if(!user) return done(null,false,req.flash('loginMessage','user not found'));

    //user found but wrong pass
    if(!user.validPassword(password)) return done(null,false,req.flash('loginMessage','right user, wrong pass'));

    //all good, return successful user
    return done(null,user);
  });
}));
};
