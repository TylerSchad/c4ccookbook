//config/pictures.js
//module to handle photo upload

var express = require('express'),
  router=express.Router(),
  multer = require('multer');

var uploading = multer({
  dest:__dirname + '../uploads/recipes/',
  limits: {fileSize:10000,files:1},
})


router.post('/upload',uploading,function(req,res){

});

module.exports = router;
