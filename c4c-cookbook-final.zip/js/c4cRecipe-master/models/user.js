//models/user.js
//user model
//load the things we need
var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

//define schema for model
var userSchema = mongoose.Schema({
  local   :{
    email:String,
    password:String,
  }
});

//methods
//generate hash
userSchema.methods.generateHash = function(password){
  return bcrypt.hashSync(password, bcrypt.genSaltSync(8),null);
};

//check if valid pass
userSchema.methods.validPassword = function(password){
  return bcrypt.compareSync(password, this.local.password);
};

//create model for users & expose to our app
module.exports = mongoose.model('User',userSchema);
